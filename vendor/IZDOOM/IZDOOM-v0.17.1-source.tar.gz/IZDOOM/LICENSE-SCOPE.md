# License scope

The combined DOOM-derived engine in this distribution is offered under GNU
GPL version 2; see `LICENSE`. This choice is compatible with the pinned
PureDOOM repository's GPL-2.0 license and the official id Software GPL release.

Independently authored IZMYSH integration and icon source are additionally
offered under GPL-2.0-or-later, preserving the parent project's existing grant.
The original vendor header and its notices are not relabeled as IZMYSH work.
MIT-licensed SDK interface files retain their existing MIT permission.

The GPL does not cover the IWAD's maps, textures, sprites, sounds or music by
virtue of covering the engine. The source archive and prebuilt IZ2S module include the original DOOM shareware v1.9 episode-one
IWAD under its separate id Software terms and the redistribution clarification
recorded in LICENSES/DOOM1-SHAREWARE.txt. This data is not relicensed under GPL.
The original IWAD bytes are preserved, and retail DOOM IWADs are not included.
Other user-supplied data requires its own redistribution rights.

This summary identifies the licenses selected for this distribution; the
complete license texts and preserved component notices control their terms.
