print("Hello from a persistent Lua slot!")
print("Press B to return to the editor.")
